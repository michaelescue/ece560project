## Simulation

This directory provides support for simulation tools.  

The main simulation tool is the opensource tools Icarus Verilog and the
gtkWave.  Alternatively, it is possible use proprietary simulation tools, as
the Xilinx ISIM and ModelSIM.

TODO: simulation models for external peripherals, such as the DarkUART.
